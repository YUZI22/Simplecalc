import os
import sys



while True: 
    print("Select operation.")
    print("1.Add")
    print("2.Subtract")
    print("3.Multiply")
    print("4.Divide")
    print("5.Power")
    print("6.Remainder")
    print("7.Prcnt")

    def add (x, y):
        return x + y

    def subtract (x, y):
        return x - y

    def multiply(x, y):
        return x * y

    def divide(x ,y):
        return x / y

    def power(x, y):
        return x ** y

    def remainder(x, y):
        return x % y

    def prcnt(x, y):
        return x * y / 100 

    choice = input("Enter choice(1/2/3/4/5/6/7): ")
    this1 = ("""The Zen of Python, by Tim Peters,
    Beautiful is better than ugly.
    Explicit is better than implicit.
    Simple is better than complex.
    Complex is better than complicated.
    Flat is better than nested.
    Sparse is better than dense.
    Readability counts.
    Special cases aren't special enough to break the rules.
    Although practicality beats purity.
    Errors should never pass silently.
    Unless explicitly silenced.
    In the face of ambiguity, refuse the temptation to guess.
    There should be one-- and preferably only one --obvious way to do it.
    Although that way may not be obvious at first unless you're Dutch.
    Now is better than never.
    Although never is often better than *right* now.
    If the implementation is hard to explain, it's a bad idea.
    If the implementation is easy to explain, it may be a good idea.
    Namespaces are one honking great idea -- let's do more of those!""")

    if choice == str("Easter egg please"):
        hi = input("You've found an easter egg! Well done!!!! (y/n): ")
        if hi == 'y':
            print(this1)
        if hi == 'n':
            break
        wyltdt = input("If the world is a simulation, why do we wake up? (y/n): ")
        if wyltdt == 'y':
            print ("The truth is hidden, you chose the correct path.")
            break
        if wyltdt == 'n':
            print("You have found nothing, you are lost")
            break
        
    if len(choice) > 1:
        print ("Only one character is allowed.")
        woultr = input("Would you like to restart? (y/n): ")
        if woultr == ('y'):
            continue
        if woultr == ('n'):
            rusure = input("Are you sure? (y/n): ")
            if rusure == ('y'):
                break
            if rusure == ('n'):
                woultr = input("Would you like to restart? (y/n): ")
                if woultr == ('y'):
                    continue
                if woultr == ('n'):
                    break 

    if choice > '7.': # (REFER TO TAG 1) : Seeing if this would work ( something to compare to )
        print ("Invalid Input")
        answer = input('Run again? (y/n): ')
        if answer == ('y'):
            continue
        if answer == ('n'):
            sys.exit()

    if choice == '123456':
        print ("Invalid Input")
        answer = input('Run again? (y/n): ')
        if answer == ('y'):
            continue
        if answer == ('n'):
            sys.exit()

    if choice == '4321, 3214, 4132, 3234, 3423':
        print ("Invalid Input")
        answer = input('Run again? (y/n): ')
        if answer == ('y'):
            continue
        if answer == ('n'):
            break

    if choice == str(' '):
        print ("Invalid Input")
        answer == input('Run again? (y/n): ')
        if answer == ('y'):
            continue
        if answer == ('n'):
            break
        
                
    num1 = float((input("Enter first number: "))) # Got rid of float() before input UPDATE: you NEED to add float to change it to a decimal number!, earlier without float it would do for example, 12+12 without float would be 1212 but with float it would be 24.0
    num2 = float((input("Enter second number: "))) # Got rid of float() before input 
    if choice == "1": # Changed single speech mark to double.
        print(num1,"+",num2,"=", add(num1,num2))
    elif choice == "2": # Changed single speech mark to double.
        print(num1,"-",num2,"=", subtract(num1,num2))
    elif choice == "3": # Changed single speech mark to double.
        print(num1,"*",num2,"=", multiply(num1,num2))
    elif choice == "4": # Changed single speech mark to double.
        print(num1,"/",num2,"=", divide(num1,num2))
    elif choice == "5": # Changed single speech mark to double.
        print(num1,"**",num2,"=", power(num1,num2))
    elif choice == "6": # Changed single speech mark to double.
        print(num1,"%",num2,"=", remainder(num1,num2))
    elif choice == "7":
        print(num1,"%",num2,"=","%", prcnt(num1,num2))  
    else:
        print("Invalid Input")




    


